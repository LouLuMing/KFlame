now=`date +%Y-%m-%d`
more ./log/myLog"$now".log
