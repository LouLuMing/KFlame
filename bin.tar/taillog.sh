now=`date +%Y-%m-%d`
tail -f ./log/myLog"$now".log
