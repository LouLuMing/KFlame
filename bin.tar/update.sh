mkdir bk
now=`date +%Y%m%d_%H%M%S`
mv myAnt.jar bk/myAnt.jar."$now"

#rm myAnt.jar.bk
#mv myAnt.jar myAnt.jar.bk

rz

